//
//  ViewController.swift
//  nmsshTest
//
//  Created by Alex Andersen on 2023/02/15.
//

import UIKit
import NMSSH
import Citadel
import NIO

class ViewController: UIViewController {

    @IBOutlet weak var Label: UILabel!
    
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
//        self.write { info in
//            print(info)
//        }
        
//        Task {
//            await self.writeCitadel()
//        }
        
//        self.saveToKeychain()
//        self.saveToKeychainAccessor()
        
        
    }
    
    func write(completion: @escaping (String) -> Void) {
        let session = NMSSHSession.connect(toHost: "192.168.31.20", port: 22, withUsername: "h.ou")
        guard session.isConnected else {
            completion("Error Not Connected")
            return
        }
        defer {
            session.disconnect()
        }

        
        
        let privateKeypath:String = Bundle.main.path(forResource: "id_rsa", ofType: "")!
        let privateKey: String = try! String(contentsOfFile: privateKeypath, encoding: String.Encoding.utf8)
               
//        session.addKnownHostName("localhost", port: 22, toFile: nil, withSalt: nil)
//        session.authenticateBy(inMemoryPublicKey: "", privateKey: privateKey, andPassword: "")
//        session.authenticate(byPublicKey: "", privateKey: privateKeypath, andPassword: nil)
        session.authenticateBy(inMemoryPublicKey: nil, privateKey: privateKey, andPassword: "alex2013")
//        session.authenticate(byPassword: "password")

//        session.addKnownHostName(<#T##hostName: String##String#>, port: <#T##Int#>, toFile: <#T##String?#>, withSalt: <#T##String?#>)
        print("session.supportedAuthenticationMethods()", session.supportedAuthenticationMethods())
                
        
        
        //        session.authenticate(byPassword: "alex2013@@$")
        guard session.isAuthorized else {
            completion("Authentication Failed")
            return
        }
        
        session.sftp.connect()
        let urlPath = Bundle.main.url(forResource: "README", withExtension: "md")!
        let strPath = Bundle.main.path(forResource: "README", ofType: "md")!

        do {
            
            let isexit = session.sftp.fileExists(atPath: "./test/NewDirect/target/albumSFTP.md")
            print("File Exist albumSFTP.md :", isexit)

            let data = try Data(contentsOf: urlPath)
            let newPath = session.sftp.createDirectory(atPath: "./test/NewDirect/")
            print("NewDir created", newPath)
            let succeeded = session.sftp.writeContents(data, toFileAtPath: "./test/NewDirect/albumSFTP.md") { prog in
                print("SFTP in progress: ",prog)
                return true
            
            }
            let isexitAf = session.sftp.fileExists(atPath: "./test/NewDirect/albumSFTP.md")
            print("File Exist albumSFTP.md :", isexitAf)
            let delete = session.sftp.removeFile(atPath: "./test/NewDirect/albumSFTP2.md")
            let deleteP = session.sftp.removeDirectory(atPath: "./test/TBD")

//            let channel = session.channel
//            let succeeddd = channel.uploadFile(strPath, to: "./test/albumSCP.zip") { prog in
//                print("SCP in progress: ",prog)
//                return true
//            }
            
            session.sftp.disconnect()
            completion("Write Successed")
        } catch {
            session.sftp.disconnect()
            completion("Error occored\(error)")
        }
    }

    func writeCitadel() async {
        do {
            
            let client = try await SSHClient.connect(host: "192.168.31.20", authenticationMethod: .passwordBased(username: "h.ou", password: "alex2013@@$"), hostKeyValidator: .acceptAnything(), reconnect: .always)
            let sftp = try await client.openSFTP()
            let urlPath = Bundle.main.url(forResource: "album", withExtension: "zip")!

            let file = try await sftp.openFile(filePath: "./test/citadel.zip", flags: [.read, .write, .create])
            let buffer = ByteBuffer(data: try Data(contentsOf: urlPath))
            try await file.write(buffer)
            try await file.close()

        } catch {
            print("Error occored \(error)")
        }
    }
    
    func saveToKeychain() {
        try! KeychainInterface.save(password: "ORIGPASS".data(using: String.Encoding.utf8)!, service: "serviceSFTP", account: "accountSFTP")
    }
    @IBAction func onTapButton(_ sender: Any) {
//       let data = try! KeychainInterface.readPassword(service: "serviceSFTP", account: "accountSFTP")
//        let str = String(data: data, encoding: String.Encoding.utf8)
//        self.Label.text = str

        if let label: Data = KeychainAccessor.shared.load(key: .ftpSettingsUserInfo) {
            self.Label.text = String(data: label, encoding: String.Encoding.utf8)
        } else {
            print("LOAD FALSE")
        }

    }
    
    func saveToKeychainAccessor() {
        guard KeychainAccessor.shared.save(key: .ftpSettingsUserInfo, value: "KeyChainAccessor".data(using: .utf8)) else {
            print("SAVE FALSE")
            return
        }
    }
}


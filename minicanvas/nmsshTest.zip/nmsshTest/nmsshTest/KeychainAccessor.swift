//
//  KeychainAccessor.swift
//  nmsshTest
//
//  Created by Alex Andersen on 2023/03/06.
//

import Foundation
import KeychainAccess

class KeychainAccessor {
    static let shared = KeychainAccessor()
    
    private let keychain: Keychain
    
    private let userDefaultKey: UserDefaultsKey = .migratedkeyChainData
    
    private let migrateKey: KeychainKey = .ftpSettingsUserInfo
    
    private init() {
        self.keychain = Keychain().synchronizable(false).accessibility(.alwaysThisDeviceOnly)
    }
    
    func load<T>(key: KeychainKey) -> T? {
        let data: Data?
        
        do {
            try data = self.keychain.getData(key.rawValue)
        }
        catch let error {
            print(error.localizedDescription)
            return nil
        }
        
        guard let theData = data else {
            return nil
        }
        
        return getUnarchiveData(theData)
        
    }
    
    func save(key: KeychainKey, value: Any) -> Bool {
        
        guard let data = getArchiveData(value) else {
            return false
        }
        do {
            try self.keychain.set(data, key: key.rawValue)
            return true
        }
        catch let error {
            print(error.localizedDescription)
            return false
        }
    }
    
    func getUnarchiveData<T>(_ data: Data?) -> T? {
        guard let data = data else {
            return nil
        }
        return try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data) as? T
    }
    
    func getArchiveData(_ object: Any) -> Data? {
        return try? NSKeyedArchiver.archivedData(withRootObject: object, requiringSecureCoding: false)
    }
}

enum UserDefaultsKey: String {
    case migratedkeyChainData = "M_G"
}

enum KeychainKey: String, CaseIterable {
    case ftpSettingsUserInfo = "ftp_info"
}

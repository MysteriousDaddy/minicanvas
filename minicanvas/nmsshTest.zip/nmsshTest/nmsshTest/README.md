# SwiftVoiceMemo

Voice Memo Example Program Using Swift.

### How do I get set up?

- Xcode 9
- Swift 4

### Who do I talk to?

If you have any questions, you can contact the following person,

- Repo owner wjnmailg@gmail.com

### License

SwiftVoiceMemo is released under an MIT license. See LICENSE for details.

